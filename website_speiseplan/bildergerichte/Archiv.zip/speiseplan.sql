-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server Version:               10.4.11-MariaDB - mariadb.org binary distribution
-- Server Betriebssystem:        Win64
-- HeidiSQL Version:             10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Exportiere Datenbank Struktur für speiseplan
CREATE DATABASE IF NOT EXISTS `speiseplan` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `speiseplan`;

-- Exportiere Struktur von Tabelle speiseplan.datum
CREATE TABLE IF NOT EXISTS `datum` (
  `d_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `datum` varchar(50) NOT NULL,
  PRIMARY KEY (`d_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

-- Daten Export vom Benutzer nicht ausgewählt

-- Exportiere Struktur von Tabelle speiseplan.gericht
CREATE TABLE IF NOT EXISTS `gericht` (
  `gid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `datum_id` int(11) unsigned NOT NULL,
  `gericht_name` varchar(50) NOT NULL,
  `bild` varchar(150) DEFAULT NULL,
  `zubereitungszeit` int(10) unsigned DEFAULT NULL,
  `zutaten` text DEFAULT NULL,
  `beschreibung` text DEFAULT NULL,
  PRIMARY KEY (`gid`),
  KEY `datum_id` (`datum_id`),
  CONSTRAINT `gericht_FK1` FOREIGN KEY (`datum_id`) REFERENCES `datum` (`d_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4;

-- Daten Export vom Benutzer nicht ausgewählt

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
